﻿using FluentValidation;
using ZambarakUz.DataAccess.Entites;

namespace ZambarakUz.Services.Validators.UserValidator
{
    public class UserGroupValidator : AbstractValidator<UserGroup>
    {
        public UserGroupValidator()
        {

        }
    }
}
